using System;
using System.Collections.Generic;
using System.IO;
using Xuux.TpmCeremony;

// مسبارُ متابعةٍ مستقلٌّ لـ WL-414 على 3e67d362. خارج الشجرة. لا يُعدِّلُ ملفاتٍ متعقَّبة.
// المنفذُ يُمرَّرُ وسيطًا (7300 لهذا المراجع). لا /dev/tpm* ولا نقلٌ غير loopback.
public sealed class GrokTransport : ICeremonyTransport
{
    public string Kind { get { return "grok-4-7-followup-on-private-swtpm"; } }
    private readonly ICeremonyTransport inner;
    public readonly string Mode;
    public int Changes;
    public readonly List<string> Edits = new List<string>();
    public readonly List<uint> Sentinels = new List<uint>();
    public readonly List<uint> Sessions = new List<uint>();
    public readonly List<uint> Foreign = new List<uint>();
    public readonly List<uint> Flushed = new List<uint>();
    public readonly List<uint> Undefines = new List<uint>();
    public uint SavedPrimary;
    private int starts, loads, creates, transientPages, sessionPages;
    private bool baselineEdited, identityEdited, stopAfterIdentity;

    public static uint U32(byte[] b, int i) { return ((uint)b[i] << 24) | ((uint)b[i + 1] << 16) | ((uint)b[i + 2] << 8) | b[i + 3]; }
    public static void Put32(byte[] b, int i, uint u) { b[i] = (byte)(u >> 24); b[i + 1] = (byte)(u >> 16); b[i + 2] = (byte)(u >> 8); b[i + 3] = (byte)u; }
    public static int Handles(uint cc) { return cc == Tpm.CC_CreatePrimary || cc == Tpm.CC_Load || cc == Tpm.CC_StartAuthSession ? 1 : 0; }

    public GrokTransport(ICeremonyTransport t, string mode)
    {
        inner = t; Mode = mode;
        if (NeedsSentinels(mode))
        {
            int n = 2;
            for (int i = 0; i < n; i++)
            {
                byte[] raw = inner.Transmit(Cmd.CreatePrimary(new byte[0], Templates.StoragePrimary()));
                if (U32(raw, 6) != 0) throw new Exception("sentinel create rc=" + Hex.U32(U32(raw, 6)));
                Sentinels.Add(U32(raw, 10));
            }
        }
        if (mode == "session-dup")
        {
            byte[] raw = inner.Transmit(Cmd.StartAuthSession(Tpm.SE_POLICY, new byte[32]));
            if (U32(raw, 6) != 0) throw new Exception("session plant rc=" + Hex.U32(U32(raw, 6)));
            Sessions.Add(U32(raw, 10));
        }
        if (mode == "foreign-survive" || mode == "define-loss-with-foreign")
        {
            uint idx = 0x01800011;
            byte[] pub = Cmd.NvPublic(idx, Tpm.S1_PROBE_ATTRIBUTES, new byte[0], 8);
            byte[] planted = inner.Transmit(Cmd.NvDefineSpace(new byte[0], new byte[] { 0x11 }, pub));
            if (U32(planted, 6) != 0) throw new Exception("foreign plant rc=" + Hex.U32(U32(planted, 6)));
            Foreign.Add(idx);
            Edits.Add("planted foreign nv " + Hex.U32(idx) + " auth=0x11 before Run");
        }
    }

    private static bool NeedsSentinels(string mode)
    {
        return mode == "r3sol01-full" || mode == "dup-triple" || mode == "descending"
            || mode == "below-start" || mode == "cross-page-dup" || mode == "omit-more0-alias"
            || mode == "omit-higher-only-alias" || mode == "omit-page2-empty-alias";
    }

    public static string ListJson(IEnumerable<uint> hs)
    {
        List<string> x = new List<string>();
        foreach (uint h in hs) x.Add("\"" + Hex.U32(h) + "\"");
        return "[" + String.Join(",", x.ToArray()) + "]";
    }

    public static List<uint> Inventory(ICeremonyTransport t, uint start)
    {
        List<uint> x = new List<uint>();
        uint next = start;
        for (int page = 0; page < 16; page++)
        {
            byte[] raw = t.Transmit(Cmd.GetCapability(1, next, 64));
            if (U32(raw, 6) != 0) throw new Exception("inventory rc=" + Hex.U32(U32(raw, 6)));
            Rd r = new Rd(Sub(raw, 10, raw.Length - 10));
            byte more = r.U8(); r.U32(); uint n = r.U32(), last = 0;
            for (uint i = 0; i < n; i++) { last = r.U32(); x.Add(last); }
            if (more == 0 || n == 0) return x;
            next = last + 1;
        }
        throw new Exception("inventory pages");
    }

    public static byte[] Sub(byte[] b, int start, int count)
    {
        byte[] n = new byte[count];
        Buffer.BlockCopy(b, start, n, 0, count);
        return n;
    }

    private byte[] Rewrite(byte[] raw, uint cc, byte[] edited, bool auth)
    {
        ushort tag = (ushort)((raw[0] << 8) | raw[1]);
        int h = Handles(cc);
        int pos = 10 + 4 * h;
        byte[] handles = Sub(raw, 10, 4 * h), prm, area;
        if (tag == Tpm.ST_SESSIONS)
        {
            int n = (int)U32(raw, pos);
            prm = Sub(raw, pos + 4, n);
            area = Sub(raw, pos + 4 + n, raw.Length - pos - 4 - n);
        }
        else { prm = Sub(raw, pos, raw.Length - pos); area = new byte[0]; }
        byte[] old = auth ? area : prm;
        Edits.Add(cc.ToString("x8") + ":" + (auth ? "auth" : "params") + ":" + Hex.Of(old) + "=>" + Hex.Of(edited));
        if (auth) area = edited; else prm = edited;
        Wr body = new Wr().Raw(handles);
        if (tag == Tpm.ST_SESSIONS) body.U32((uint)prm.Length);
        body.Raw(prm).Raw(area);
        byte[] b = body.Bytes();
        Changes++;
        return new Wr().U16(tag).U32((uint)(10 + b.Length)).U32(0).Raw(b).Bytes();
    }

    private static int ParentNameAlgOffset(byte[] cd)
    {
        Rd q = new Rd(cd);
        uint count = q.U32();
        if (count > 4) throw new Exception("pcrSelect count=" + count);
        for (uint i = 0; i < count; i++) { q.U16(); byte sz = q.U8(); q.Raw(sz); }
        ushort dlen = q.U16();
        q.Raw(dlen);
        q.U8();
        int at = cd.Length - q.Remaining;
        if (at < 0 || at + 1 >= cd.Length) throw new Exception("parentNameAlg offset=" + at);
        return at;
    }

    private static byte[] HandlesPage(byte more, params uint[] hs)
    {
        Wr w = new Wr().U8(more).U32(1).U32((uint)hs.Length);
        for (int i = 0; i < hs.Length; i++) w.U32(hs[i]);
        return w.Bytes();
    }

    private byte[] Creation(byte[] p, uint cc)
    {
        Rd r = new Rd(p);
        byte[] priv = cc == Tpm.CC_Create ? r.B2B() : null;
        byte[] pub = r.B2B(), cd = r.B2B(), ch = r.B2B();
        ushort tag = r.U16(); uint hierarchy = r.U32(); byte[] digest = r.B2B();
        byte[] rest = r.Raw(r.Remaining);
        if (Mode == "cd-missing") cd = Sub(cd, 0, 41);
        if (Mode == "cd-extra") cd = new Wr().Raw(cd).B2B(new byte[0]).Bytes();
        if (Mode == "parentalg-sha-on-primary" || Mode == "parentalg-null-on-create" || Mode == "parentalg-ffff")
        {
            int at = ParentNameAlgOffset(cd);
            Edits.Add("parentNameAlg-at=" + at + " was=" + cd[at].ToString("x2") + cd[at + 1].ToString("x2"));
            if (Mode == "parentalg-sha-on-primary") { cd[at] = 0x00; cd[at + 1] = 0x0B; }
            else if (Mode == "parentalg-null-on-create") { cd[at] = 0x00; cd[at + 1] = 0x10; }
            else { cd[at] = 0xFF; cd[at + 1] = 0xFF; }
            if (Mode != "parentalg-ffff") ch = Sha.H(cd);
        }
        if (Mode == "pcr-empty")
        {
            Rd d = new Rd(cd);
            if (d.U32() != 0) throw new Exception("expected empty pcrSelect");
            d.B2B();
            cd = new Wr().U32(0).B2B(new byte[0]).Raw(d.Raw(d.Remaining)).Bytes();
            ch = Sha.H(cd);
        }
        if (Mode == "creationhash-flip") ch[0] ^= 1;
        if (Mode == "creation-hier-invalid") hierarchy = 0x40000002;
        if (Mode == "creation-hier-platform") hierarchy = 0x4000000C;
        if (Mode == "creation-hier-endorsement") hierarchy = 0x4000000B;
        if (Mode == "creation-hier-null") hierarchy = 0x40000007;
        if (Mode == "creation-digest-1") digest = new byte[1];
        if (Mode == "creation-digest-63") digest = new byte[63];
        if (Mode == "creation-digest-65") digest = new byte[65];
        if (Mode == "creation-digest-100") digest = new byte[100];
        Wr w = new Wr();
        if (priv != null) w.B2B(priv);
        return w.B2B(pub).B2B(cd).B2B(ch).U16(tag).U32(hierarchy).B2B(digest).Raw(rest).Bytes();
    }

    private bool TransientInventory(uint cc, byte[] cmd)
    {
        return cc == Tpm.CC_GetCapability && U32(cmd, 10) == 1 && (U32(cmd, 14) & 0xFF000000) == 0x80000000;
    }

    private bool SessionInventory(uint cc, byte[] cmd)
    {
        return cc == Tpm.CC_GetCapability && U32(cmd, 10) == 1 && U32(cmd, 14) == 0x02000000;
    }

    public byte[] Transmit(byte[] cmd)
    {
        uint cc = U32(cmd, 6);
        if (stopAfterIdentity && cc == Tpm.CC_GetCapability && !identityEdited)
        {
            // لا نصلُ هنا: العلمُ يُرفعُ بعدَ حقنِ الهوية، والإيقافُ على الأمرِ التالي.
        }
        if (stopAfterIdentity)
            throw new CeremonyFailedException("PROBE_IDENTITY_ACCEPTED_DESCENDING_PROPERTIES", 0);

        if (Mode == "foreign-identical-loss" && cc == Tpm.CC_NV_DefineSpace && Changes == 0)
        {
            Rd c = new Rd(cmd); c.Raw(14); uint az = c.U32(); c.Raw((int)az); c.B2B(); byte[] pub = c.B2B();
            byte[] planted = inner.Transmit(Cmd.NvDefineSpace(new byte[0], new byte[] { 0x11 }, pub));
            byte[] original = inner.Transmit(cmd);
            Changes++;
            Edits.Add("foreign identical public planted rc=" + Hex.U32(U32(planted, 6)) + "; original define rc=" + Hex.U32(U32(original, 6)) + " discarded");
            throw new IOException("GROK_FOREIGN_IDENTICAL_AND_LOST_DEFINE_REPLY");
        }
        if ((Mode == "define-loss" || Mode == "define-loss-with-foreign") && cc == Tpm.CC_NV_DefineSpace && Changes == 0)
        {
            byte[] original = inner.Transmit(cmd);
            Changes++;
            Edits.Add("define actual responseCode=" + Hex.U32(U32(original, 6)) + " discarded after execution (not a malformed body)");
            throw new IOException("GROK_DEFINE_SUCCESS_RESPONSE_DISCARDED");
        }
        if (Mode == "create-loss" && cc == Tpm.CC_Create && Changes == 0)
        {
            byte[] original = inner.Transmit(cmd);
            Changes++;
            Edits.Add("Create actual responseCode=" + Hex.U32(U32(original, 6)) + " discarded after execution");
            throw new IOException("GROK_CREATE_SUCCESS_RESPONSE_DISCARDED");
        }
        if (cc == Tpm.CC_NV_UndefineSpace) Undefines.Add(U32(cmd, 14));
        if (cc == Tpm.CC_FlushContext) Flushed.Add(U32(cmd, 10));

        byte[] raw = inner.Transmit(cmd);
        if (U32(raw, 6) != 0) return raw;

        if (cc == Tpm.CC_StartAuthSession) starts++;
        if (cc == Tpm.CC_Load) loads++;
        if (cc == Tpm.CC_CreatePrimary) creates++;
        if (cc == Tpm.CC_CreatePrimary && creates == 1) SavedPrimary = U32(raw, 10);

        if (Mode == "property-below" && cc == Tpm.CC_GetCapability && U32(cmd, 10) == 6 && U32(cmd, 14) == 0x105 && Changes == 0)
            return Rewrite(raw, cc, new Wr().U8(0).U32(6).U32(1).U32(0x104).U32(0).Bytes(), false);
        if (Mode == "property-descending" && cc == Tpm.CC_GetCapability && U32(cmd, 10) == 6 && U32(cmd, 14) == 0x105 && !identityEdited)
        {
            identityEdited = true;
            stopAfterIdentity = true;
            return Rewrite(raw, cc, new Wr().U8(0).U32(6).U32(5)
                .U32(0x109).U32(Tpm.EXPECTED_VENDOR_4)
                .U32(0x108).U32(Tpm.EXPECTED_VENDOR_3)
                .U32(0x107).U32(Tpm.EXPECTED_VENDOR_2)
                .U32(0x106).U32(Tpm.EXPECTED_VENDOR_1)
                .U32(0x105).U32(Tpm.EXPECTED_MANUFACTURER).Bytes(), false);
        }

        if (TransientInventory(cc, cmd))
        {
            transientPages++;
            uint asked = U32(cmd, 14);
            Edits.Add("transient-page asked=" + Hex.U32(asked) + " n=" + transientPages);
            if (!baselineEdited && transientPages == 1 && Sentinels.Count == 2)
            {
                if (Mode == "r3sol01-full")
                {
                    baselineEdited = true;
                    return Rewrite(raw, cc, HandlesPage(0, Sentinels[0], Sentinels[0]), false);
                }
                if (Mode == "dup-triple")
                {
                    baselineEdited = true;
                    return Rewrite(raw, cc, HandlesPage(0, Sentinels[0], Sentinels[0], Sentinels[0]), false);
                }
                if (Mode == "descending")
                {
                    baselineEdited = true;
                    return Rewrite(raw, cc, HandlesPage(0, Sentinels[1], Sentinels[0]), false);
                }
                if (Mode == "below-start" || Mode == "cross-page-dup" || Mode == "omit-page2-empty-alias")
                {
                    baselineEdited = true;
                    return Rewrite(raw, cc, HandlesPage(1, Sentinels[0]), false);
                }
                if (Mode == "omit-more0-alias")
                {
                    baselineEdited = true;
                    return Rewrite(raw, cc, HandlesPage(0, Sentinels[0]), false);
                }
                if (Mode == "omit-higher-only-alias")
                {
                    baselineEdited = true;
                    return Rewrite(raw, cc, HandlesPage(0, Sentinels[1]), false);
                }
            }
            if (transientPages == 2 && (Mode == "below-start" || Mode == "cross-page-dup"))
            {
                Edits.Add("page2-inject asked=" + Hex.U32(asked) + " returning sentinel0=" + Hex.U32(Sentinels[0]));
                return Rewrite(raw, cc, HandlesPage(0, Sentinels[0]), false);
            }
            if (transientPages == 2 && Mode == "omit-page2-empty-alias")
            {
                Edits.Add("page2-empty asked=" + Hex.U32(asked));
                return Rewrite(raw, cc, HandlesPage(0), false);
            }
        }

        if (Mode == "session-dup" && SessionInventory(cc, cmd) && sessionPages == 0)
        {
            sessionPages++;
            return Rewrite(raw, cc, HandlesPage(0, Sessions[0], Sessions[0]), false);
        }
        if (Mode == "baseline-partial-transient" && TransientInventory(cc, cmd) && Changes == 0)
            return Rewrite(raw, cc, HandlesPage(0, 0x01000001), false);
        if (Mode == "baseline-partial-session" && SessionInventory(cc, cmd) && Changes == 0)
            return Rewrite(raw, cc, HandlesPage(0, 0x01000001), false);
        if (Mode == "count-over" && TransientInventory(cc, cmd) && Changes == 0)
        {
            Wr w = new Wr().U8(0).U32(1).U32(65);
            for (int i = 0; i < 65; i++) w.U32(0x80000000u + (uint)i);
            return Rewrite(raw, cc, w.Bytes(), false);
        }

        bool alias = Mode == "r3sol01-full" || Mode == "omit-more0-alias" || Mode == "omit-higher-only-alias" || Mode == "omit-page2-empty-alias";
        if (alias && cc == Tpm.CC_CreatePrimary && creates == 1 && Sentinels.Count == 2)
        {
            uint victim = Mode == "omit-higher-only-alias" ? Sentinels[0] : Sentinels[1];
            uint actual = U32(raw, 10);
            Put32(raw, 10, victim);
            Changes++;
            Edits.Add("primary-handle:" + Hex.U32(actual) + "=>" + Hex.U32(victim));
            return raw;
        }
        if (Mode == "handle-reissued" && cc == Tpm.CC_Load && loads == 1)
        {
            uint actual = U32(raw, 10);
            Put32(raw, 10, SavedPrimary);
            Changes++;
            Edits.Add("load-handle:" + Hex.U32(actual) + "=>live-primary:" + Hex.U32(SavedPrimary));
            return raw;
        }
        if (Mode == "session-wrongclass" && cc == Tpm.CC_StartAuthSession && starts == 1)
        {
            Edits.Add("session-handle:" + Hex.U32(U32(raw, 10)) + "=>0x800000ff");
            Put32(raw, 10, 0x800000ff);
            Changes++;
            return raw;
        }

        if (Changes > 0 && !Mode.StartsWith("auth-") && !Mode.StartsWith("policy-") && Mode != "load-name-flip" && Mode != "parentalg-null-on-create")
            return raw;

        if (Mode == "auth-pw-as-policy" && cc == Tpm.CC_NV_DefineSpace && Changes == 0)
            return Rewrite(raw, cc, new Wr().B2B(new byte[32]).U8(0).B2B(new byte[0]).Bytes(), true);
        if (Mode == "auth-pw-attrs08" && cc == Tpm.CC_NV_DefineSpace && Changes == 0)
            return Rewrite(raw, cc, new Wr().B2B(new byte[0]).U8(0x08).B2B(new byte[0]).Bytes(), true);
        if (Mode == "auth-policy-as-password" && cc == Tpm.CC_NV_Increment && U32(cmd, 22) != Tpm.RS_PW && Changes == 0)
            return Rewrite(raw, cc, new Wr().B2B(new byte[0]).U8(1).B2B(new byte[0]).Bytes(), true);
        if (Mode == "auth-policy-nonce16" && cc == Tpm.CC_NV_Increment && U32(cmd, 22) != Tpm.RS_PW && Changes == 0)
            return Rewrite(raw, cc, new Wr().B2B(new byte[16]).U8(0).B2B(new byte[0]).Bytes(), true);
        if (Mode == "auth-policy-attrs08" && cc == Tpm.CC_NV_Increment && U32(cmd, 22) != Tpm.RS_PW && Changes == 0)
        {
            Rd q = new Rd(AuthArea(raw, cc));
            byte[] nonce = q.B2B();
            return Rewrite(raw, cc, new Wr().B2B(nonce).U8(0x08).B2B(new byte[0]).Bytes(), true);
        }

        if ((Mode.StartsWith("cd-") || Mode.StartsWith("creation") || Mode.StartsWith("parentalg") || Mode == "pcr-empty" || Mode == "creationhash-flip") && cc == Tpm.CC_CreatePrimary && creates == 1 && Mode != "parentalg-null-on-create")
            return Rewrite(raw, cc, Creation(ParamsOf(raw, cc), cc), false);
        if (Mode == "parentalg-null-on-create" && cc == Tpm.CC_Create && Changes == 0)
            return Rewrite(raw, cc, Creation(ParamsOf(raw, cc), cc), false);
        if (Mode == "load-name-flip" && cc == Tpm.CC_Load && loads == 1)
            return Rewrite(raw, cc, delegate_flip_last(ParamsOf(raw, cc)), false);
        if (Mode.StartsWith("policy-") && cc == Tpm.CC_PolicySigned && Changes == 0)
            return Rewrite(raw, cc, PolicyTicket(ParamsOf(raw, cc)), false);
        return raw;
    }

    private static byte[] delegate_flip_last(byte[] p) { p[p.Length - 1] ^= 1; return p; }

    private byte[] ParamsOf(byte[] raw, uint cc)
    {
        ushort tag = (ushort)((raw[0] << 8) | raw[1]);
        int pos = 10 + 4 * Handles(cc);
        if (tag == Tpm.ST_SESSIONS) { int n = (int)U32(raw, pos); return Sub(raw, pos + 4, n); }
        return Sub(raw, pos, raw.Length - pos);
    }

    private byte[] AuthArea(byte[] raw, uint cc)
    {
        ushort tag = (ushort)((raw[0] << 8) | raw[1]);
        int pos = 10 + 4 * Handles(cc);
        int n = (int)U32(raw, pos);
        return Sub(raw, pos + 4 + n, raw.Length - pos - 4 - n);
    }

    private byte[] PolicyTicket(byte[] p)
    {
        Rd q = new Rd(p);
        byte[] timeout = q.B2B(); ushort tag = q.U16(); uint hierarchy = q.U32(); byte[] d = q.B2B();
        if (Mode == "policy-timeout-byte") timeout = new byte[] { 0xAA };
        if (Mode == "policy-hier-invalid") hierarchy = 0x40000002;
        if (Mode == "policy-hier-platform") hierarchy = 0x4000000C;
        if (Mode == "policy-hier-endorsement") hierarchy = 0x4000000B;
        if (Mode == "policy-hier-owner") hierarchy = 0x40000001;
        if (Mode == "policy-digest-1") d = new byte[] { 0xAA };
        if (Mode == "policy-digest-65") d = new byte[65];
        return new Wr().B2B(timeout).U16(tag).U32(hierarchy).B2B(d).Bytes();
    }
}

public static class GrokFollowup
{
    private static string Q(string s)
    {
        if (s == null) return "null";
        return "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n") + "\"";
    }

    private static string StagesFor(string mode)
    {
        if (mode == "clean" || mode == "foreign-survive" || mode == "auth-policy-as-password"
            || mode == "auth-policy-nonce16" || mode == "auth-policy-attrs08") return "ALL";
        if (mode.StartsWith("policy-") || mode.StartsWith("creation") || mode.StartsWith("cd-")
            || mode.StartsWith("parentalg") || mode == "pcr-empty" || mode == "creationhash-flip"
            || mode == "load-name-flip" || mode == "handle-reissued" || mode == "session-wrongclass"
            || mode.StartsWith("omit") || mode == "r3sol01-full" || mode == "create-loss"
            || mode == "dup-triple" || mode == "descending" || mode == "below-start" || mode == "cross-page-dup")
            return "S2";
        return "S1";
    }

    private static void Direct()
    {
        int fail = 0;
        byte[] pwCmd = Cmd.NvDefineSpace(new byte[0], new byte[0], Cmd.NvPublic(0x01800001, Tpm.S1_PROBE_ATTRIBUTES, new byte[0], 8));
        byte[] polCmd = Cmd.NvIncrement(0x01800001, Cmd.PolicyAuth(0x03000000, new byte[32]));
        byte[] pwAuth = new Wr().B2B(new byte[0]).U8(1).B2B(new byte[0]).Bytes();
        byte[] polAuth = new Wr().B2B(new byte[32]).U8(0).B2B(new byte[0]).Bytes();
        Expect("direct-pw-cmd-policy-auth", delegate() {
            ParseAuth(pwCmd, polAuth, 0);
        }, true);
        Expect("direct-pw-cmd-password-auth", delegate() {
            ParseAuth(pwCmd, pwAuth, 0);
        }, false);
        Expect("direct-pol-cmd-password-auth", delegate() {
            ParseAuth(polCmd, pwAuth, 0);
        }, true);
        Expect("direct-pol-cmd-policy-auth", delegate() {
            ParseAuth(polCmd, polAuth, 0);
        }, false);
        byte[] capCmd = Cmd.GetCapability(1, 0x80000000, 64);
        Expect("direct-dup-handles", delegate() {
            ResponseSchema.Check(Tpm.CC_GetCapability, capCmd, new Wr().U8(0).U32(1).U32(2).U32(0x80000000).U32(0x80000000).Bytes());
        }, true);
        Expect("direct-descending", delegate() {
            ResponseSchema.Check(Tpm.CC_GetCapability, capCmd, new Wr().U8(0).U32(1).U32(2).U32(0x80000001).U32(0x80000000).Bytes());
        }, true);
        Expect("direct-below-start", delegate() {
            byte[] cmd2 = Cmd.GetCapability(1, 0x80000001, 64);
            ResponseSchema.Check(Tpm.CC_GetCapability, cmd2, new Wr().U8(0).U32(1).U32(1).U32(0x80000000).Bytes());
        }, true);
        Expect("direct-count-over", delegate() {
            Wr w = new Wr().U8(0).U32(1).U32(65);
            for (int i = 0; i < 65; i++) w.U32(0x80000000u + (uint)i);
            ResponseSchema.Check(Tpm.CC_GetCapability, capCmd, w.Bytes());
        }, true);
        Expect("direct-omit-more0-schema-accepts", delegate() {
            ResponseSchema.Check(Tpm.CC_GetCapability, capCmd, new Wr().U8(0).U32(1).U32(1).U32(0x80000000).Bytes());
        }, false);
        byte[] propCmd = Cmd.GetCapability(6, 0x105, 5);
        Expect("direct-property-below", delegate() {
            ResponseSchema.Check(Tpm.CC_GetCapability, propCmd, new Wr().U8(0).U32(6).U32(1).U32(0x104).U32(0).Bytes());
        }, true);
        Expect("direct-property-descending-accepted", delegate() {
            ResponseSchema.Check(Tpm.CC_GetCapability, propCmd, new Wr().U8(0).U32(6).U32(2).U32(0x106).U32(1).U32(0x105).U32(2).Bytes());
        }, false);
        Console.WriteLine("{\"direct\":\"done\"}");
    }

    private static void ParseAuth(byte[] cmd, byte[] auth, int respHandles)
    {
        byte[] body = new Wr().U32(0).Raw(auth).Bytes();
        byte[] resp = new Wr().U16(Tpm.ST_SESSIONS).U32((uint)(10 + body.Length)).U32(0).Raw(body).Bytes();
        bool[] kinds = ResponseSchema.ExpectedPasswordSessions(cmd, 1);
        Resp.Parse(resp, respHandles, Tpm.ST_SESSIONS, 1, kinds);
    }

    private static void Expect(string name, Action act, bool shouldThrow)
    {
        try
        {
            act();
            Console.WriteLine("{\"direct\":" + Q(name) + ",\"threw\":false,\"expectedThrow\":" + (shouldThrow ? "true" : "false") + "}");
        }
        catch (Exception e)
        {
            Console.WriteLine("{\"direct\":" + Q(name) + ",\"threw\":true,\"expectedThrow\":" + (shouldThrow ? "true" : "false") + ",\"type\":" + Q(e.GetType().Name) + ",\"message\":" + Q(e.Message) + "}");
        }
    }

    public static int Main(string[] args)
    {
        string mode = args[0];
        if (mode == "direct") { Direct(); return 0; }
        int port = args.Length > 1 ? int.Parse(args[1]) : 7300;
        string stages = StagesFor(mode);
        using (SwtpmLoopbackTransport inner = new SwtpmLoopbackTransport("127.0.0.1", port))
        {
            GrokTransport t = new GrokTransport(inner, mode);
            List<uint> nvBefore = GrokTransport.Inventory(inner, 0x01000000);
            List<uint> trBefore = GrokTransport.Inventory(inner, 0x80000000);
            List<uint> seBefore = GrokTransport.Inventory(inner, 0x02000000);
            CeremonyReport report = new CeremonyRehearsal(t).Run(stages);
            string nvAfter = "null", trAfter = "null", seAfter = "null", invErr = null;
            try
            {
                nvAfter = GrokTransport.ListJson(GrokTransport.Inventory(inner, 0x01000000));
                trAfter = GrokTransport.ListJson(GrokTransport.Inventory(inner, 0x80000000));
                seAfter = GrokTransport.ListJson(GrokTransport.Inventory(inner, 0x02000000));
            }
            catch (Exception e) { invErr = e.GetType().Name + ": " + e.Message; }
            Console.Write("{\"mode\":" + Q(mode) + ",\"stages\":" + Q(stages) + ",\"changes\":" + t.Changes + ",\"edits\":[");
            for (int i = 0; i < t.Edits.Count; i++) { if (i != 0) Console.Write(","); Console.Write(Q(t.Edits[i])); }
            Console.Write("],\"sentinels\":" + GrokTransport.ListJson(t.Sentinels));
            Console.Write(",\"sessionsPlanted\":" + GrokTransport.ListJson(t.Sessions));
            Console.Write(",\"foreign\":" + GrokTransport.ListJson(t.Foreign));
            Console.Write(",\"flushed\":" + GrokTransport.ListJson(t.Flushed));
            Console.Write(",\"undefines\":" + GrokTransport.ListJson(t.Undefines));
            Console.Write(",\"savedPrimary\":" + Q(Hex.U32(t.SavedPrimary)));
            Console.Write(",\"nvBefore\":" + GrokTransport.ListJson(nvBefore));
            Console.Write(",\"transientsBefore\":" + GrokTransport.ListJson(trBefore));
            Console.Write(",\"sessionsBefore\":" + GrokTransport.ListJson(seBefore));
            Console.Write(",\"nvAfter\":" + nvAfter + ",\"transientsAfter\":" + trAfter + ",\"sessionsAfter\":" + seAfter);
            if (invErr != null) Console.Write(",\"inventoryError\":" + Q(invErr));
            Console.WriteLine(",\"report\":" + report.ToJson() + "}");
        }
        return 0;
    }
}
