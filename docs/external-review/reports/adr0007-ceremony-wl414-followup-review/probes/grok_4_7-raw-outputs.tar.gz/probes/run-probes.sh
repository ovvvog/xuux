#!/bin/bash
# مشغّلُ مسابرِ grok_4_7. المنفذُ 7300/7301 فقط. لا يقتلُ إلا محاكيَ هذا الدليل.
set -u
ROOT=/tmp/wl414-followup/reviewers/grok_4_7
REPO=$ROOT/repo
OUT=$ROOT/raw
EXE=$ROOT/probes/GrokFollowup.exe
PORT=7300
CTRL=7301
mkdir -p "$OUT"
cd "$REPO"

snapshot() {
  ps -eo pid,ppid,lstart,args | awk '/swtpm socket/ && !/awk/ {print}'
}

kill_mine() {
  local pids
  pids=$(ps -eo pid,args | awk -v dir="$ROOT/swtpm-state" '/swtpm socket/ && index($0, dir) {print $1}')
  if [ -n "$pids" ]; then
    kill $pids 2>/dev/null || true
    sleep 0.2
    kill -9 $pids 2>/dev/null || true
  fi
  # منفذُنا فقط إن بقيَ مستمعٌ من محاكيِنا
  local lp
  lp=$(ss -ltnp | awk -v p=":$PORT" '$4 ~ p && /swtpm/ {print}' | sed -n 's/.*pid=\([0-9]*\).*/\1/p' | head -1)
  if [ -n "$lp" ]; then
    local cmd
    cmd=$(tr '\0' ' ' < /proc/$lp/cmdline 2>/dev/null || true)
    case "$cmd" in
      *"$ROOT/swtpm-state"*) kill "$lp" 2>/dev/null || true ;;
    esac
  fi
}

run_one() {
  local mode="$1"
  local st=$ROOT/swtpm-state
  echo "==== $mode ===="
  kill_mine
  rm -rf "$st"
  mkdir -p "$st"
  swtpm socket --tpm2 --tpmstate "dir=$st" \
    --server type=tcp,port=$PORT,bindaddr=127.0.0.1 \
    --ctrl type=tcp,port=$CTRL,bindaddr=127.0.0.1 \
    --flags not-need-init,startup-clear \
    --pid "file=$st/swtpm.pid" --daemon
  local ready=0
  for i in 1 2 3 4 5 6 7 8 9 10; do
    if tpm2_getcap --tcti="swtpm:host=127.0.0.1,port=$PORT" properties-fixed >/dev/null 2>&1; then
      ready=1
      break
    fi
    sleep 0.3
  done
  if [ "$ready" != 1 ]; then
    echo "SWTPM_NOT_READY" | tee "$OUT/$mode.err"
    echo 9 > "$OUT/$mode.exit"
    kill_mine
    return
  fi
  local before after
  before=$(snapshot | awk '/swtpm socket/ {print $1}' | sort | tr '\n' ' ')
  echo "$before" > "$OUT/$mode.swtpm-before"
  set +e
  timeout 180 mono "$EXE" "$mode" "$PORT" > "$OUT/$mode.json" 2>"$OUT/$mode.err"
  echo $? > "$OUT/$mode.exit"
  # عدٌّ فوريٌّ بعدَ خروجِ mono لا بعدَ قتلِ المحاكي
  snapshot > "$OUT/$mode.swtpm-after-immediate.txt"
  echo "exit=$(cat "$OUT/$mode.exit") bytes=$(wc -c < "$OUT/$mode.json")"
  kill_mine
  snapshot > "$OUT/$mode.swtpm-after-kill.txt"
}

echo "DIRECT"
mono "$EXE" direct > "$OUT/direct.json" 2>"$OUT/direct.err"
echo $? > "$OUT/direct.exit"

MODES="
r3sol01-full
dup-triple
descending
below-start
cross-page-dup
omit-more0-alias
omit-higher-only-alias
omit-page2-empty-alias
session-dup
baseline-partial-transient
baseline-partial-session
count-over
define-loss
define-loss-with-foreign
foreign-identical-loss
auth-pw-as-policy
auth-pw-attrs08
property-below
property-descending
creation-hier-invalid
creation-hier-platform
creation-hier-endorsement
creation-hier-null
creation-digest-1
creation-digest-63
creation-digest-65
creation-digest-100
cd-missing
cd-extra
creationhash-flip
pcr-empty
parentalg-ffff
parentalg-sha-on-primary
parentalg-null-on-create
load-name-flip
handle-reissued
session-wrongclass
policy-timeout-byte
policy-hier-invalid
policy-hier-platform
policy-hier-endorsement
policy-hier-owner
policy-digest-1
policy-digest-65
create-loss
auth-policy-as-password
auth-policy-nonce16
auth-policy-attrs08
foreign-survive
clean
"
for m in $MODES; do
  run_one "$m"
done
kill_mine
echo ALL_PROBES_DONE
snapshot > "$OUT/swtpm-final.txt"
