using System;
using System.Collections.Generic;
using System.IO;
using Xuux.TpmCeremony;

public sealed class IndependentFollowupTransport : ICeremonyTransport
{
    public string Kind { get { return "independent-followup-transport"; } }
    private readonly ICeremonyTransport inner;
    public readonly string Mode;
    public int Changes;
    public readonly List<string> Edits = new List<string>();
    public readonly List<uint> Sentinels = new List<uint>();
    public readonly List<uint> Flushed = new List<uint>();
    private int starts, loads, creates, createsPrimary, undefines;
    private bool baselineEdited;
    private bool cleanupTriggered;
    private uint livePrimaryHandle;

    public static uint U32(byte[] b, int i) { return ((uint)b[i] << 24) | ((uint)b[i + 1] << 16) | ((uint)b[i + 2] << 8) | b[i + 3]; }
    public static ushort U16(byte[] b, int i) { return (ushort)((b[i] << 8) | b[i + 1]); }
    public static void Put32(byte[] b, int i, uint u) { b[i] = (byte)(u >> 24); b[i + 1] = (byte)(u >> 16); b[i + 2] = (byte)(u >> 8); b[i + 3] = (byte)u; }
    public static int Handles(uint cc) { return cc == Tpm.CC_CreatePrimary || cc == Tpm.CC_Load || cc == Tpm.CC_StartAuthSession ? 1 : 0; }
    public static byte[] Sub(byte[] b, int start, int count) { byte[] n = new byte[count]; Buffer.BlockCopy(b, start, n, 0, count); return n; }

    public IndependentFollowupTransport(ICeremonyTransport t, string mode)
    {
        inner = t;
        Mode = mode;

        // For attack-r3sol01-full: pre-create two sentinel primary objects on the TPM before rehearsal
        if (mode == "attack-r3sol01-full")
        {
            for (int i = 0; i < 2; i++)
            {
                byte[] raw = inner.Transmit(Cmd.CreatePrimary(new byte[0], Templates.StoragePrimary()));
                if (U32(raw, 6) != 0) throw new Exception("attack-r3sol01 sentinel create error: rc=" + Hex.U32(U32(raw, 6)));
                uint h = U32(raw, 10);
                Sentinels.Add(h);
            }
        }
    }

    public static string ListJson(IEnumerable<uint> hs)
    {
        List<string> x = new List<string>();
        foreach (uint h in hs) x.Add("\"" + Hex.U32(h) + "\"");
        return "[" + String.Join(",", x.ToArray()) + "]";
    }

    public static List<uint> Inventory(ICeremonyTransport t, uint start)
    {
        List<uint> x = new List<uint>();
        uint next = start;
        for (int page = 0; page < 16; page++)
        {
            byte[] raw = t.Transmit(Cmd.GetCapability(1, next, 64));
            if (U32(raw, 6) != 0) throw new Exception("inventory error: rc=" + Hex.U32(U32(raw, 6)));
            Rd r = new Rd(Sub(raw, 10, raw.Length - 10));
            byte more = r.U8(); r.U32(); uint n = r.U32(), last = 0;
            for (uint i = 0; i < n; i++) { last = r.U32(); x.Add(last); }
            if (more == 0) return x;
            if (n == 0) throw new Exception("inventory stuck");
            next = last + 1;
        }
        throw new Exception("inventory pages exceeded");
    }

    private byte[] Rewrite(byte[] raw, uint cc, Func<byte[], byte[]> f, bool auth)
    {
        ushort tag = U16(raw, 0);
        int h = Handles(cc);
        int pos = 10 + 4 * h;
        byte[] handles = Sub(raw, 10, 4 * h), prm, area;
        if (tag == Tpm.ST_SESSIONS)
        {
            int n = (int)U32(raw, pos);
            prm = Sub(raw, pos + 4, n);
            area = Sub(raw, pos + 4 + n, raw.Length - pos - 4 - n);
        }
        else
        {
            prm = Sub(raw, pos, raw.Length - pos);
            area = new byte[0];
        }
        byte[] old = auth ? area : prm;
        string oldHex = Hex.Of(old);
        byte[] edited = f(old);
        Edits.Add(cc.ToString("x8") + ":tag=" + tag.ToString("x4") + ":" + (auth ? "auth" : "params") + ":" + oldHex + "=>" + Hex.Of(edited));
        if (auth) area = edited; else prm = edited;
        Wr body = new Wr().Raw(handles);
        if (tag == Tpm.ST_SESSIONS) body.U32((uint)prm.Length);
        body.Raw(prm).Raw(area);
        byte[] b = body.Bytes();
        Changes++;
        return new Wr().U16(tag).U32((uint)(10 + b.Length)).U32(0).Raw(b).Bytes();
    }

    public byte[] Transmit(byte[] cmd)
    {
        uint cc = U32(cmd, 6);

        // Priority 4: define-response-loss-actual
        // Transmit NV_DefineSpace to TPM so it executes, then throw IOException (actual loss of reply)
        if (Mode == "define-response-loss-actual" && cc == Tpm.CC_NV_DefineSpace && Changes == 0)
        {
            byte[] rawSuccess = inner.Transmit(cmd);
            uint rcSuccess = U32(rawSuccess, 6);
            Changes++;
            Edits.Add("define-response-loss-actual: NV_DefineSpace executed on TPM with rc=" + Hex.U32(rcSuccess) + "; dropping response now");
            throw new IOException("INDEPENDENT_SIMULATED_CARRIER_DROP_AFTER_EXECUTION");
        }

        // Priority 1: inventory-duplicate-across-pages
        // First page returns more=1, count=1, handle=0x80000000. Second page (asked 0x80000001) returns more=0, count=1, handle=0x80000000.
        if (Mode == "inventory-duplicate-across-pages" && cc == Tpm.CC_GetCapability && Changes < 2)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32(); uint count = c.U32();
            if (cap == 1 && prop == 0x80000000u && Changes == 0)
            {
                Changes++;
                Edits.Add("inventory-duplicate-across-pages: page 1 returning more=1 count=1 handle=0x80000000");
                byte[] body = new Wr().U8(1).U32(1).U32(1).U32(0x80000000u).Bytes();
                return new Wr().U16(Tpm.ST_NO_SESSIONS).U32((uint)(10 + body.Length)).U32(0).Raw(body).Bytes();
            }
            if (cap == 1 && prop == 0x80000001u && Changes == 1)
            {
                Changes++;
                Edits.Add("inventory-duplicate-across-pages: page 2 returning more=0 count=1 handle=0x80000000 (duplicate across pages / below askedProp)");
                byte[] body = new Wr().U8(0).U32(1).U32(1).U32(0x80000000u).Bytes();
                return new Wr().U16(Tpm.ST_NO_SESSIONS).U32((uint)(10 + body.Length)).U32(0).Raw(body).Bytes();
            }
        }

        // Track flushes
        if (cc == Tpm.CC_FlushContext) Flushed.Add(U32(cmd, 10));

        byte[] raw = inner.Transmit(cmd);
        if (U32(raw, 6) != 0) return raw;

        if (cc == Tpm.CC_StartAuthSession) starts++;
        if (cc == Tpm.CC_Load) loads++;
        if (cc == Tpm.CC_CreatePrimary)
        {
            createsPrimary++;
            livePrimaryHandle = U32(raw, 10);
        }
        if (cc == Tpm.CC_Create) creates++;
        if (cc == Tpm.CC_NV_UndefineSpace) undefines++;

        // Priority 1: attack-r3sol01-full
        // 1) On baseline transient enumeration, return duplicate page [Sentinels[0], Sentinels[0]] to hide Sentinels[1]
        if (Mode == "attack-r3sol01-full" && cc == Tpm.CC_GetCapability && !baselineEdited)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32();
            if (cap == 1 && prop == 0x80000000u)
            {
                baselineEdited = true;
                Edits.Add("attack-r3sol01-full: injecting duplicate handles [" + Hex.U32(Sentinels[0]) + ", " + Hex.U32(Sentinels[0]) + "] to hide victim " + Hex.U32(Sentinels[1]));
                return Rewrite(raw, cc, delegate(byte[] p) {
                    return new Wr().U8(0).U32(1).U32(2).U32(Sentinels[0]).U32(Sentinels[0]).Bytes();
                }, false);
            }
        }
        // If the duplicate page was accepted (vulnerable code), then at CreatePrimary replace returned handle with hidden victim Sentinels[1]
        if (Mode == "attack-r3sol01-full" && cc == Tpm.CC_CreatePrimary && createsPrimary == 1)
        {
            uint victim = Sentinels[1];
            uint actual = U32(raw, 10);
            Put32(raw, 10, victim);
            Changes++;
            Edits.Add("attack-r3sol01-full: replacing CreatePrimary handle " + Hex.U32(actual) + " with victim " + Hex.U32(victim));
            return raw;
        }

        // Priority 1: inventory-multi-dup-in-page
        if (Mode == "inventory-multi-dup-in-page" && cc == Tpm.CC_GetCapability && Changes == 0)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32();
            if (cap == 1 && prop == 0x80000000u)
            {
                return Rewrite(raw, cc, delegate(byte[] p) {
                    return new Wr().U8(0).U32(1).U32(3).U32(0x80000000u).U32(0x80000000u).U32(0x80000000u).Bytes();
                }, false);
            }
        }

        // Priority 1: inventory-descending-order
        if (Mode == "inventory-descending-order" && cc == Tpm.CC_GetCapability && Changes == 0)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32();
            if (cap == 1 && prop == 0x80000000u)
            {
                return Rewrite(raw, cc, delegate(byte[] p) {
                    return new Wr().U8(0).U32(1).U32(2).U32(0x80000001u).U32(0x80000000u).Bytes();
                }, false);
            }
        }

        // Priority 1: inventory-handle-below-start
        if (Mode == "inventory-handle-below-start" && cc == Tpm.CC_GetCapability && Changes == 0)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32();
            if (cap == 1 && prop == 0x80000000u)
            {
                // cmd was for 0x80000000, let's inject askedProp=0x80000005 in response returning 0x80000002
                // or returning handle 0x7FFFFFFF which is < 0x80000000
                return Rewrite(raw, cc, delegate(byte[] p) {
                    return new Wr().U8(0).U32(1).U32(1).U32(0x7fffffffu).Bytes();
                }, false);
            }
        }

        // Priority 1: inventory-prop-below-start
        if (Mode == "inventory-prop-below-start" && cc == Tpm.CC_GetCapability && Changes == 0)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32();
            if (cap == 6) // properties
            {
                return Rewrite(raw, cc, delegate(byte[] p) {
                    // return property 0x00000050 when askedProp is >= 0x00000100
                    return new Wr().U8(0).U32(6).U32(1).U32(0x00000050u).U32(1).Bytes();
                }, false);
            }
        }

        // Priority 1: inventory-count-exceeds-requested
        if (Mode == "inventory-count-exceeds-requested" && cc == Tpm.CC_GetCapability && Changes == 0)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32();
            if (cap == 1 && prop == 0x80000000u)
            {
                return Rewrite(raw, cc, delegate(byte[] p) {
                    // return count 65 when askedCount is 64
                    Wr w = new Wr().U8(0).U32(1).U32(65);
                    for (uint i = 0; i < 65; i++) w.U32(0x80000000u + i);
                    return w.Bytes();
                }, false);
            }
        }

        // Priority 1: handle-reissued-live
        // CC_Load returns the live primary handle which is still active in _transients
        if (Mode == "handle-reissued-live" && cc == Tpm.CC_Load && loads == 1 && Changes == 0)
        {
            uint actual = U32(raw, 10);
            Put32(raw, 10, livePrimaryHandle);
            Changes++;
            Edits.Add("handle-reissued-live: Load returned handle " + Hex.U32(actual) + " replaced with live primary " + Hex.U32(livePrimaryHandle));
            return raw;
        }

        // Priority 2: Auth Profile Matching
        // 1) auth-policy-on-password-cmd: On CC_NV_DefineSpace (password auth), rewrite response auth to policy profile
        if (Mode == "auth-policy-on-password-cmd" && cc == Tpm.CC_NV_DefineSpace && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                // policy profile: nonce 32, attrs 0x00, hmac 0
                return new Wr().B2B(new byte[32]).U8(0x00).B2B(new byte[0]).Bytes();
            }, true);
        }

        // 2) auth-password-on-policy-cmd: On CC_NV_Increment (policy session), rewrite response auth to password profile
        if (Mode == "auth-password-on-policy-cmd" && cc == Tpm.CC_NV_Increment && U32(cmd, 22) != Tpm.RS_PW && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                // password profile: nonce 0, attrs 0x01, hmac 0
                return new Wr().B2B(new byte[0]).U8(0x01).B2B(new byte[0]).Bytes();
            }, true);
        }

        // 3) auth-policy-nonce16: On CC_NV_Increment (policy session), nonce len 16
        if (Mode == "auth-policy-nonce16" && cc == Tpm.CC_NV_Increment && U32(cmd, 22) != Tpm.RS_PW && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                return new Wr().B2B(new byte[16]).U8(0x00).B2B(new byte[0]).Bytes();
            }, true);
        }

        // 4) auth-policy-attrs08: On CC_NV_Increment (policy session), attrs 0x08
        if (Mode == "auth-policy-attrs08" && cc == Tpm.CC_NV_Increment && U32(cmd, 22) != Tpm.RS_PW && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                return new Wr().B2B(new byte[32]).U8(0x08).B2B(new byte[0]).Bytes();
            }, true);
        }

        // 5) auth-policy-attrs01: On CC_NV_Increment (policy session), attrs 0x01
        if (Mode == "auth-policy-attrs01" && cc == Tpm.CC_NV_Increment && U32(cmd, 22) != Tpm.RS_PW && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                return new Wr().B2B(new byte[32]).U8(0x01).B2B(new byte[0]).Bytes();
            }, true);
        }

        // Priority 2: Ticket Hierarchies
        // CreationTicket in CreatePrimary
        if (Mode.StartsWith("creation-ticket-") && cc == Tpm.CC_CreatePrimary && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                Rd r = new Rd(p);
                byte[] pub = r.B2B(), cd = r.B2B(), ch = r.B2B();
                ushort tag = r.U16();
                uint hierarchy = r.U32();
                byte[] tdg = r.B2B();
                byte[] nm = r.B2B();
                if (Mode == "creation-ticket-owner") hierarchy = 0x40000001u;
                else if (Mode == "creation-ticket-null") hierarchy = 0x40000007u;
                else if (Mode == "creation-ticket-endorsement") hierarchy = 0x4000000Bu;
                else if (Mode == "creation-ticket-platform") hierarchy = 0x4000000Cu;
                else if (Mode == "creation-ticket-revoke") hierarchy = 0x40000002u;
                else if (Mode == "creation-ticket-invalid0") hierarchy = 0x40000000u;
                else if (Mode == "creation-ticket-invalid3") hierarchy = 0x40000003u;
                return new Wr().B2B(pub).B2B(cd).B2B(ch).U16(tag).U32(hierarchy).B2B(tdg).B2B(nm).Bytes();
            }, false);
        }

        // AuthTicket in PolicySigned
        if (Mode.StartsWith("policysigned-ticket-") && cc == Tpm.CC_PolicySigned && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                Rd r = new Rd(p);
                byte[] to = r.B2B();
                ushort tag = r.U16();
                uint hierarchy = r.U32();
                byte[] td = r.B2B();
                if (Mode == "policysigned-ticket-owner") hierarchy = 0x40000001u;
                else if (Mode == "policysigned-ticket-null") hierarchy = 0x40000007u;
                else if (Mode == "policysigned-ticket-endorsement") hierarchy = 0x4000000Bu;
                else if (Mode == "policysigned-ticket-platform") hierarchy = 0x4000000Cu;
                else if (Mode == "policysigned-ticket-revoke") hierarchy = 0x40000002u;
                else if (Mode == "policysigned-ticket-digest-65") td = new byte[65];
                else if (Mode == "policysigned-ticket-digest-64") td = new byte[64];
                return new Wr().B2B(to).U16(tag).U32(hierarchy).B2B(td).Bytes();
            }, false);
        }

        // Creation ticket digest lengths in Create
        if (Mode.StartsWith("create-ticket-digest-") && cc == Tpm.CC_Create && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                Rd r = new Rd(p);
                byte[] priv = r.B2B(), pub = r.B2B(), cd = r.B2B(), ch = r.B2B();
                ushort tag = r.U16();
                uint hierarchy = r.U32();
                byte[] tdg = r.B2B();
                int targetLen = 64;
                if (Mode == "create-ticket-digest-0") targetLen = 0;
                else if (Mode == "create-ticket-digest-1") targetLen = 1;
                else if (Mode == "create-ticket-digest-32") targetLen = 32;
                else if (Mode == "create-ticket-digest-65") targetLen = 65;
                else if (Mode == "create-ticket-digest-100") targetLen = 100;
                else if (Mode == "create-ticket-digest-64") targetLen = 64;
                return new Wr().B2B(priv).B2B(pub).B2B(cd).B2B(ch).U16(tag).U32(hierarchy).B2B(new byte[targetLen]).Bytes();
            }, false);
        }

        // Priority 2: CreationData internal fields in CreatePrimary
        if (Mode.StartsWith("creation-data-") && cc == Tpm.CC_CreatePrimary && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                Rd r = new Rd(p);
                byte[] pub = r.B2B(), cd = r.B2B(), ch = r.B2B();
                ushort tag = r.U16();
                uint hierarchy = r.U32();
                byte[] tdg = r.B2B();
                byte[] nm = r.B2B();

                if (Mode == "creation-data-tail-2")
                {
                    // Truncate cd so it only has 2 tail fields instead of 3
                    // cd format: count(4), pcrSelect..., pcrDigest(2+len), locality(1), parentNameAlg(2), fields...
                    Rd q = new Rd(cd);
                    uint count = q.U32();
                    for (uint k = 0; k < count; k++) { q.U16(); byte sz = q.U8(); q.Raw(sz); }
                    ushort dl = q.U16(); q.Raw(dl); q.U8(); q.U16();
                    byte[] f1 = q.B2B(); byte[] f2 = q.B2B(); // omit f3
                    int headerLen = cd.Length - q.Remaining - f1.Length - 2 - f2.Length - 2;
                    cd = new Wr().Raw(Sub(cd, 0, headerLen)).B2B(f1).B2B(f2).Bytes();
                    ch = Sha.H(cd);
                }
                else if (Mode == "creation-data-tail-4")
                {
                    // Add a 4th tail field
                    cd = new Wr().Raw(cd).B2B(new byte[] { 1, 2, 3 }).Bytes();
                    ch = Sha.H(cd);
                }
                else if (Mode == "creation-data-parentalg-ffff")
                {
                    // Corrupt parentNameAlg to 0xFFFF
                    Rd q = new Rd(cd);
                    uint count = q.U32();
                    for (uint k = 0; k < count; k++) { q.U16(); byte sz = q.U8(); q.Raw(sz); }
                    ushort dl = q.U16(); q.Raw(dl); q.U8();
                    int algOffset = cd.Length - q.Remaining;
                    cd[algOffset] = 0xFF; cd[algOffset + 1] = 0xFF;
                    ch = Sha.H(cd);
                }
                else if (Mode == "creation-data-parentalg-sha1")
                {
                    // Corrupt parentNameAlg to 0x0004 (ALG_SHA1)
                    Rd q = new Rd(cd);
                    uint count = q.U32();
                    for (uint k = 0; k < count; k++) { q.U16(); byte sz = q.U8(); q.Raw(sz); }
                    ushort dl = q.U16(); q.Raw(dl); q.U8();
                    int algOffset = cd.Length - q.Remaining;
                    cd[algOffset] = 0x00; cd[algOffset + 1] = 0x04;
                    ch = Sha.H(cd);
                }
                else if (Mode == "creation-data-pcr-empty-valid")
                {
                    // Valid encoding: count=0, dlen=0
                    Rd q = new Rd(cd);
                    uint count = q.U32();
                    if (count != 0) throw new Exception("expected count=0 in CreatePrimary cd");
                    q.B2B(); // old pcrDigest (32 bytes)
                    byte[] remainder = q.Raw(q.Remaining);
                    cd = new Wr().U32(0).B2B(new byte[0]).Raw(remainder).Bytes();
                    ch = Sha.H(cd);
                }
                else if (Mode == "creation-data-pcr-dlen16")
                {
                    // Invalid: count=0, dlen=16
                    Rd q = new Rd(cd);
                    uint count = q.U32();
                    q.B2B();
                    byte[] remainder = q.Raw(q.Remaining);
                    cd = new Wr().U32(count).B2B(new byte[16]).Raw(remainder).Bytes();
                    ch = Sha.H(cd);
                }

                return new Wr().B2B(pub).B2B(cd).B2B(ch).U16(tag).U32(hierarchy).B2B(tdg).B2B(nm).Bytes();
            }, false);
        }

        // Priority 2: creationhash-mismatch
        if (Mode == "creationhash-mismatch" && cc == Tpm.CC_CreatePrimary && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                Rd r = new Rd(p);
                byte[] pub = r.B2B(), cd = r.B2B(), ch = r.B2B();
                ushort tag = r.U16();
                uint hierarchy = r.U32();
                byte[] tdg = r.B2B();
                byte[] nm = r.B2B();
                ch[0] ^= 0x01; // flip a bit in ch
                return new Wr().B2B(pub).B2B(cd).B2B(ch).U16(tag).U32(hierarchy).B2B(tdg).B2B(nm).Bytes();
            }, false);
        }

        // Priority 2: load-name-mismatch
        if (Mode == "load-name-mismatch" && cc == Tpm.CC_Load && loads == 1 && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                Rd r = new Rd(p);
                byte[] nm = r.B2B();
                nm[nm.Length - 1] ^= 0x01;
                return new Wr().B2B(nm).Bytes();
            }, false);
        }

        // Priority 2: policysigned-timeout-nonzero-exp0
        if (Mode == "policysigned-timeout-nonzero-exp0" && cc == Tpm.CC_PolicySigned && Changes == 0)
        {
            return Rewrite(raw, cc, delegate(byte[] p) {
                Rd r = new Rd(p);
                byte[] to = r.B2B();
                ushort tag = r.U16();
                uint hierarchy = r.U32();
                byte[] td = r.B2B();
                // Expiration was 0, so inject 8 bytes of timeout
                return new Wr().B2B(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 }).U16(tag).U32(hierarchy).B2B(td).Bytes();
            }, false);
        }

        // Priority 3: baseline-partial-transient
        // During SnapshotBaseline, on capability query for transients (cap=1, prop=0x80000000), return NV class handle 0x01000001
        if (Mode == "baseline-partial-transient" && cc == Tpm.CC_GetCapability && Changes == 0)
        {
            Rd c = new Rd(cmd); c.Raw(10); uint cap = c.U32(); uint prop = c.U32();
            if (cap == 1 && prop == 0x80000000u)
            {
                Changes++;
                Edits.Add("baseline-partial-transient: returning NV handle 0x01000001 for transient capability query");
                byte[] body = new Wr().U8(0).U32(1).U32(1).U32(0x01000001u).Bytes();
                return new Wr().U16(Tpm.ST_NO_SESSIONS).U32((uint)(10 + body.Length)).U32(0).Raw(body).Bytes();
            }
        }

        return raw;
    }
}

public static class IndependentFollowup
{
    private static string Q(string s)
    {
        if (s == null) return "null";
        return "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n") + "\"";
    }

    public static int Main(string[] args)
    {
        if (args.Length < 1)
        {
            Console.Error.WriteLine("Usage: IndependentFollowup.exe <mode> [port] [stages]");
            return 2;
        }
        string mode = args[0];
        int port = args.Length > 1 ? int.Parse(args[1]) : 7200;
        string stages = args.Length > 2 ? args[2] : "ALL";

        using (SwtpmLoopbackTransport inner = new SwtpmLoopbackTransport("127.0.0.1", port))
        {
            // Plant foreign NV index if requested
            if (mode == "foreign-nv-preservation")
            {
                uint foreignIdx = 0x01800099u;
                byte[] foreignPub = Cmd.NvPublic(foreignIdx, 0x00040004u, new byte[0], 8);
                byte[] plantDef = inner.Transmit(Cmd.NvDefineSpace(new byte[0], new byte[0], foreignPub));
                if (IndependentFollowupTransport.U32(plantDef, 6) != 0)
                    Console.Error.WriteLine("Note: foreign NV define returned rc=" + Hex.U32(IndependentFollowupTransport.U32(plantDef, 6)));
            }

            List<uint> nvBefore = IndependentFollowupTransport.Inventory(inner, 0x01000000u);
            List<uint> transientBefore = IndependentFollowupTransport.Inventory(inner, 0x80000000u);
            List<uint> sessionsBefore = IndependentFollowupTransport.Inventory(inner, 0x02000000u);

            IndependentFollowupTransport t = new IndependentFollowupTransport(inner, mode);
            CeremonyReport report = null;
            string runError = null;
            try
            {
                report = new CeremonyRehearsal(t).Run(stages);
            }
            catch (Exception ex)
            {
                runError = ex.Message;
            }

            List<uint> nvAfter = IndependentFollowupTransport.Inventory(inner, 0x01000000u);
            List<uint> transientAfter = IndependentFollowupTransport.Inventory(inner, 0x80000000u);
            List<uint> sessionsAfter = IndependentFollowupTransport.Inventory(inner, 0x02000000u);

            Console.Write("{\"mode\":" + Q(mode) + ",\"changes\":" + t.Changes + ",\"edits\":[");
            for (int i = 0; i < t.Edits.Count; i++)
            {
                if (i != 0) Console.Write(",");
                Console.Write(Q(t.Edits[i]));
            }
            Console.Write("],\"sentinels\":" + IndependentFollowupTransport.ListJson(t.Sentinels) + ",\"flushed\":" + IndependentFollowupTransport.ListJson(t.Flushed));
            Console.Write(",\"nvBefore\":" + IndependentFollowupTransport.ListJson(nvBefore) + ",\"transientsBefore\":" + IndependentFollowupTransport.ListJson(transientBefore) + ",\"sessionsBefore\":" + IndependentFollowupTransport.ListJson(sessionsBefore));
            Console.Write(",\"nvAfter\":" + IndependentFollowupTransport.ListJson(nvAfter) + ",\"transientsAfter\":" + IndependentFollowupTransport.ListJson(transientAfter) + ",\"sessionsAfter\":" + IndependentFollowupTransport.ListJson(sessionsAfter));
            if (runError != null) Console.Write(",\"uncaughtException\":" + Q(runError));
            Console.WriteLine(",\"report\":" + (report != null ? report.ToJson() : "null") + "}");
        }
        return 0;
    }
}
