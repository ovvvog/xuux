#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="/tmp/wl414-followup/reviewers/gemini_3_8_flash"
PROBE_DIR="$BASE_DIR/probes"
RAW_DIR="$BASE_DIR/raw"
LOG_DIR="$BASE_DIR/logs"
PORT=7200
CTRL_PORT=7201

mkdir -p "$RAW_DIR" "$LOG_DIR"
COMMANDS_LOG="$LOG_DIR/commands.log"
ORPHAN_LOG="$LOG_DIR/orphan_tracking.log"
: > "$COMMANDS_LOG"
: > "$ORPHAN_LOG"

MODES=(
  # Priority 1: Handles
  "attack-r3sol01-full"
  "inventory-multi-dup-in-page"
  "inventory-descending-order"
  "inventory-duplicate-across-pages"
  "inventory-handle-below-start"
  "inventory-prop-below-start"
  "inventory-count-exceeds-requested"
  "handle-reissued-live"

  # Priority 2: Response Auth Profiles
  "auth-policy-on-password-cmd"
  "auth-password-on-policy-cmd"
  "auth-policy-nonce16"
  "auth-policy-attrs08"
  "auth-policy-attrs01"

  # Priority 2: Ticket Hierarchies
  "creation-ticket-owner"
  "creation-ticket-null"
  "creation-ticket-endorsement"
  "creation-ticket-platform"
  "creation-ticket-revoke"
  "creation-ticket-invalid0"
  "creation-ticket-invalid3"
  "policysigned-ticket-owner"
  "policysigned-ticket-null"
  "policysigned-ticket-endorsement"
  "policysigned-ticket-platform"
  "policysigned-ticket-revoke"

  # Priority 2: Ticket Digest Lengths
  "create-ticket-digest-0"
  "create-ticket-digest-1"
  "create-ticket-digest-32"
  "create-ticket-digest-65"
  "create-ticket-digest-100"
  "create-ticket-digest-64"
  "policysigned-ticket-digest-65"
  "policysigned-ticket-digest-64"

  # Priority 2: CreationData & Internal Fields
  "creation-data-tail-2"
  "creation-data-tail-4"
  "creation-data-parentalg-ffff"
  "creation-data-parentalg-sha1"
  "creation-data-pcr-empty-valid"
  "creation-data-pcr-dlen16"
  "creationhash-mismatch"
  "load-name-mismatch"
  "policysigned-timeout-nonzero-exp0"

  # Priority 3: Partial Baseline
  "baseline-partial-transient"

  # Priority 4: Missing Responses & Foreign NV Index
  "define-response-loss-actual"
  "foreign-nv-preservation"

  # Clean Baseline Rehearsal
  "clean-rehearsal"
)

echo "Starting test suite of ${#MODES[@]} probe modes on swtpm port $PORT..."
echo "Timestamp: $(date -u)" >> "$COMMANDS_LOG"

for mode in "${MODES[@]}"; do
  echo "=== Running mode: $mode ==="
  STATE_DIR="$RAW_DIR/state-$mode"
  rm -rf "$STATE_DIR"
  mkdir -p "$STATE_DIR"
  PID_FILE="$STATE_DIR/swtpm.pid"

  # Count swtpm before starting this test
  SWTPM_BEFORE=$(pgrep -f "port=$PORT" || true)

  # Launch swtpm on assigned port 7200 / ctrl 7201
  swtpm socket --tpm2 \
    --tpmstate dir="$STATE_DIR" \
    --server type=tcp,port=$PORT,bindaddr=127.0.0.1 \
    --ctrl type=tcp,port=$CTRL_PORT,bindaddr=127.0.0.1 \
    --flags not-need-init,startup-clear \
    --pid file="$PID_FILE" --daemon > "$RAW_DIR/$mode.launch.log" 2>&1
  LAUNCH_RC=$?
  echo "launch $mode exit=$LAUNCH_RC" >> "$COMMANDS_LOG"

  if [ "$LAUNCH_RC" -ne 0 ]; then
    echo "ERROR: Failed to launch swtpm for $mode" >&2
    exit 1
  fi

  # Wait for port to open
  for i in $(seq 1 20); do
    if nc -z 127.0.0.1 $PORT 2>/dev/null; then break; fi
    sleep 0.05
  done

  # Run probe
  set +e
  mono "$PROBE_DIR/IndependentFollowup.exe" "$mode" "$PORT" "ALL" > "$RAW_DIR/$mode.json" 2> "$RAW_DIR/$mode.stderr"
  PROBE_RC=$?
  set -e
  echo "$PROBE_RC" > "$RAW_DIR/$mode.exit"
  echo "probe $mode exit=$PROBE_RC" >> "$COMMANDS_LOG"

  # Read PID and kill swtpm
  if [ -f "$PID_FILE" ]; then
    SWTPM_PID=$(cat "$PID_FILE")
    kill "$SWTPM_PID" 2>/dev/null || true
    # wait for socket release
    for i in $(seq 1 50); do
      if ! nc -z 127.0.0.1 $PORT 2>/dev/null; then break; fi
      sleep 0.05
    done
  fi

  # Check immediately for orphaned swtpm on this port
  SWTPM_AFTER=$(pgrep -f "port=$PORT" || true)
  if [ -n "$SWTPM_AFTER" ]; then
    echo "ORPHAN DETECTED for $mode: PID $SWTPM_AFTER" >> "$ORPHAN_LOG"
    echo "CRITICAL: Orphan swtpm process $SWTPM_AFTER detected for mode $mode!" >&2
    kill -9 $SWTPM_AFTER 2>/dev/null || true
  else
    echo "CLEAN: 0 orphan processes for $mode" >> "$ORPHAN_LOG"
  fi

  # Clean up state dir
  rm -rf "$STATE_DIR"
done

echo "All ${#MODES[@]} probe modes completed."
